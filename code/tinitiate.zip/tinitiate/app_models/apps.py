from django.apps import AppConfig


class AppModelsConfig(AppConfig):
    name = 'app_models'
