from django.shortcuts import render  
from django.conf import settings
from django.core.files.storage import FileSystemStorage

def upload_doc(request):

    if request.method == 'POST' and request.FILES['upload_file']:

        UploadFile = request.FILES['upload_file']
        upload = FileSystemStorage()

        filename = upload.save(UploadFile.name, UploadFile)
        file_upload_status = upload.url(filename)

        return render( request
                      ,'upload_files.html'
                      ,{'file_upload_status': file_upload_status})

    return render(request, 'upload_files.html')
