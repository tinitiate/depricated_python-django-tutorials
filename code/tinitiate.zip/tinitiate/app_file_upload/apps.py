from django.apps import AppConfig


class AppFileUploadConfig(AppConfig):
    name = 'app_file_upload'
