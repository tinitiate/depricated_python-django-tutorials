from django.apps import AppConfig


class AppDjangoTemplatesInheritanceConfig(AppConfig):
    name = 'app_django_templates_inheritance'
