from django.urls import path
from . import views

urlpatterns = [
    # For URL: localhost:8000
    path('ti_blocks', views.template_blocks, name='template_blocks'),
]
