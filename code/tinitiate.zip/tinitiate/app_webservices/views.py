from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.http import HttpResponse 
from app_webservices.models import Projects
from app_webservices.serializers import ProjectsSerializer 


@api_view(['GET', 'POST'])
def ws_test(request):

    if request.method == "GET":
        return Response({"data": "GET Example"}, status=status.HTTP_200_OK)

    elif request.method == "POST":
        return Response({"data": "POST Example."}, status=status.HTTP_200_OK)

    else:
        data = {"Error": {"status": 400,
                          "message": "Request Error"}}

        return Response(data, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'POST'])
def all_projects(request):

    """
    Request Type: GET
    =================
    1. List All Projects rows
    2. Request URL: localhost:800/app_webservices/all_projects
    
    Request Type: POST
    ==================
    1. Insert ONE Project row
    2. Request URL: localhost:800/app_webservices/all_projects
    3. Sample Data:
    {"proj_id":1,"proj_name":"Data Base","proj_date":"2016-05-18T03:02:00.776594Z","proj_cost":10000.22}
    """

    if request.method == 'GET':
        projects = Projects.objects.all()
        serializer = ProjectsSerializer(projects,context={'request': request} ,many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = ProjectsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'DELETE'])
def single_project(request, in_proj_id):
    
    """
    Request Type: GET
    =================
    1. List All Projects rows
    2. Request URL: localhost:800/app_webservices/single_project/1
    
    Request Type: PUT
    =================
    1. Insert ONE Project row
    2. Request URL: localhost:800/app_webservices/single_project/1
    3. Sample PUT:
    {"proj_name":"Data Base and Python"}
    
    Request Type: DELETE
    ====================
    1. Insert ONE Project row
    2. Request URL: localhost:800/app_webservices/single_project/1
    """

    try:
        project = Projects.objects.get(proj_id=in_proj_id)
    except Projects.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = ProjectsSerializer(project,context={'request': request})
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = ProjectsSerializer(project, data=request.data,context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        project.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

