from django.db import models

class Projects(models.Model):
    proj_id = models.IntegerField(primary_key=True)
    proj_name = models.CharField(max_length=128,default=None, blank=True, null=True)
    proj_date = models.DateTimeField(default=None, blank=True, null=True)
    proj_cost = models.DecimalField(max_digits=20,decimal_places=4,default=None, blank=True, null=True)
