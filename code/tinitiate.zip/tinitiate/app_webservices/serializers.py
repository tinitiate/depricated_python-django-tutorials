from rest_framework import serializers
from .models import Projects

class ProjectsSerializer(serializers.ModelSerializer):

    class Meta:
        model = Projects
        fields = ('proj_id', 'proj_name', 'proj_date', 'proj_cost')
