from django.apps import AppConfig


class AppMultipleViewFilesConfig(AppConfig):
    name = 'app_multiple_view_files'
