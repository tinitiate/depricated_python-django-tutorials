from django.apps import AppConfig


class AppTiConfig(AppConfig):
    name = 'app_ti'
