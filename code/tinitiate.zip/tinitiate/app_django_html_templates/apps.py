from django.apps import AppConfig


class AppDjangoHtmlTemplatesConfig(AppConfig):
    name = 'app_django_html_templates'
