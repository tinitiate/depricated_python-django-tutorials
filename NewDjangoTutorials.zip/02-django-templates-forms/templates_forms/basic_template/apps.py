from django.apps import AppConfig


class BasicTemplateConfig(AppConfig):
    name = 'basic_template'
