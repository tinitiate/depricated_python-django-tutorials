from django.apps import AppConfig


class Pages404UploadConfig(AppConfig):
    name = 'pages_404_upload'
