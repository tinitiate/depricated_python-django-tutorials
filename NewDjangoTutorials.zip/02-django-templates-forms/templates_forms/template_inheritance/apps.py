from django.apps import AppConfig


class TemplateInheritanceConfig(AppConfig):
    name = 'template_inheritance'
