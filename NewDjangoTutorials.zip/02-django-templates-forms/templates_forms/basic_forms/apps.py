from django.apps import AppConfig


class BasicFormsConfig(AppConfig):
    name = 'basic_forms'
