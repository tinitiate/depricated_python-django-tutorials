from django.apps import AppConfig


class AppClassBasedViewsConfig(AppConfig):
    name = 'app_class_based_views'
