from django.apps import AppConfig


class AppCookiesConfig(AppConfig):
    name = 'app_cookies'
