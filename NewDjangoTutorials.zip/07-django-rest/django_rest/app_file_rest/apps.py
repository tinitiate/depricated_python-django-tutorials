from django.apps import AppConfig


class AppFileRestConfig(AppConfig):
    name = 'app_file_rest'
