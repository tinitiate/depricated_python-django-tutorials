import urllib.request
import urllib.parse
  
# trying to read the URL
try:
    x = urllib.request.urlopen('http://127.0.0.1:8000/file_rest/random_number/')
    print(x.read())
  
# Catching the exception generated    
except Exception as e :
    print(str(e))