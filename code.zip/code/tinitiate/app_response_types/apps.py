from django.apps import AppConfig


class AppResponseTypesConfig(AppConfig):
    name = 'app_response_types'
