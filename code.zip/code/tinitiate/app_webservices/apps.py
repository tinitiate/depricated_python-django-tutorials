from django.apps import AppConfig


class AppWebservicesConfig(AppConfig):
    name = 'app_webservices'
