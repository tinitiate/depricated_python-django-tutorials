from django.apps import AppConfig


class AppViewsConfig(AppConfig):
    name = 'app_views'
