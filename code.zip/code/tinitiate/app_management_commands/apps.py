from django.apps import AppConfig


class AppManagementCommandsConfig(AppConfig):
    name = 'app_management_commands'
