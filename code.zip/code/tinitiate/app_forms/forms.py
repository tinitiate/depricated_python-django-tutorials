from django import forms

class TestForm(forms.Form):
    # HTMl INPUT Box
    userid = forms.CharField()
    passwd = forms.CharField()

    form_choices = (
        (1, 'Food'),
        (2, 'Drinks'),
        (3, 'Movies'),
        (4, 'Rest'),
        (5, 'Sports')
    )

    # HTML Drop Down Box
    DropDownBox = forms.ChoiceField(choices=form_choices)

    # HTML Radio Buttons
    RadioButtons = forms.ChoiceField(choices=form_choices, widget=forms.RadioSelect)

    # HTML Multi Select Text Box
    MultiSelect = forms.MultipleChoiceField(choices=form_choices)

    # HTML Check Box
    CheckBox = forms.MultipleChoiceField(choices=form_choices, widget=forms.CheckboxSelectMultiple)
