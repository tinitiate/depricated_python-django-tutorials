from django.apps import AppConfig


class AppHomeConfig(AppConfig):
    name = 'app_home'
