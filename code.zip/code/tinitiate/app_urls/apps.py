from django.apps import AppConfig


class AppUrlsConfig(AppConfig):
    name = 'app_urls'
